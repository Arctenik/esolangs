this zip contains itself! woah!!

(assembled by Arctenik)